# ansible windows mssql2014 express 
playbook for installing windows 2014 sql server express edition

#TODO
Parameterize the answer files and make this a role and possibly add it in galaxy.
