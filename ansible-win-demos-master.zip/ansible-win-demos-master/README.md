# Ansible Windows Demos

This is a collection of demos I've created while working with Ansible and
Windows. See each individual folder for more details of the demo.
