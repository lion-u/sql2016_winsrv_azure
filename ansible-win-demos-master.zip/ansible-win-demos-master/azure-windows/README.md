Collection of scripts that was used with Ansible Tower to provision a Windows
VM and run some Ansible script on it.

The full demo can be viewed [here](https://ansible.wistia.com/medias/esyegro23t).

This is really a barebones demo and some variables need to be defined outside
this playbook. Watch the video to find out how it all fit together.
